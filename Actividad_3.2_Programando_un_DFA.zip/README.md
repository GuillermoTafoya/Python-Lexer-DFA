# Actividad 3.2 Programando un DFA
# Integrantes:
Guillermo Tafoya Milo - A01633790
Engels Emiliano Miranda Palacios - A01423398
Jorge Hernández Montero - A01733616

Fecha: 13 de marzo del 2022